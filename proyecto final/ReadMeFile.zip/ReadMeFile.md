# Análisis procesos de Contratación Estatal - Colombia - 2015 - 2020
---

*Presentado por: Mónica Robayo* 

## **Descripción y Motivación** 📋 🚀
---

<font size="3"> Analizar los datos de procesos de contratación estatal disponibles. El objetivo es procesarlos, analizarlos y realizar gráficas de comportamiento usando librerías de matplotlib y Pandas.  Así mismo realizar un análisis de redes de los procesos de contratación, con el fin de identificar la relación que existe entre las entidades estatales y los adjudicatarios principales.</font> 


<font size="3">Algunas preguntas y problemas que motivaron el proyecto:</font> 

+ <font size="3">¿Cuánto dinero se ha ejecutado por tipos de contratación?, las más comunes son mínima cuantía, selección abreviada, subasta inversa, licitación pública.</font> 


+ <font size="3">¿Cuáles modalidades de contratación se adjudican de forma más frecuente?</font> 


+ <font size="3">¿Cómo ha el comportamiento de la contratación a traves de estos últimos años?</font> 


+ <font size="3">¿Cuáles son aquellos posibles bienes y/o servicios que más se contratan, es posible saberlo por tipo de contratación?</font> 


+ <font size="3">¿Cuales son los Departamentos que más adjudican procesos?</font> 


+ <font size="3">¿ En el manejo de los recursos, como se ve plasmado por modalidades de Contratación? ¿Por cual Modalidad se ejecutan más recursos?</font> 


+ <font size="3">Teniendo en cuenta las entidades de orden Nacional y Territorial.¿ Es posible ver las adjudicaciones por modalidad de   contratación?</font> 


+ <font size="3">Analisis de redes de proveedores a nivel Nacional, Territorial y Ejercito Nacional. ¿Se presentaran nodos y aristas comunes?</font> 


+ <font size="3">Reflexionar sobre la importancia en términos de política pública sobre la pluralidad de oferentes, un principio fundamental en la contratación estatal, que sirve como instrumento de política pública, en terminos de optimizar los recursos y velar por el bienestar de la sociedad.</font> 

## **Métodos Usados** 🔧⚙️
---

<font size="3">**1.Libreria Pandas:**

 - La utilice para realizar Dataframe de la información.
 
 - Me ayudó a organizar y a leer el contenido de la información.
 
 - Uso de Group by y agg(count y sum), con el fin de contabilizar y sumar las variables de estudio.
 
 - Multiple Group by, para agrupar diferentes variables y analizar la información.
 
 - Series de Tiempo dt.day y definición de funciones con formato fecha.
 
 - Con las series de tiempo, utilice timestamp y unstack 
 
 - Utilice sort_values para organizar la información de manera ascendente 
    
 - Indexación [ ] y eliminación (drop) de variables que no son tenidas en cuenta, sea el caso. 
 
<font size="3">**2.Matplotlib:**

 - Realice gráficas de torta
 
 - Utilicé Gráficas de Barra de manera horizontal 
 
 - Para realizar las gráficas utilice algunas opciones como explode, startangle, pctdistance, bbox_to_anchor, loc y autopct
 
 - Utilice la Paleta de Colores cmap='Paired'
 
 
<font size="3">**3.Networkx**
 
 - Lo utilicé para realizar el análisis de redes.
 
 - Utilice la invocación de un G de la siguiente manera: nx.read_adjlist(G) , ya que la información esta de manera matricial.
 
 - Para realizar la red, hice uso de Matplotlip con las siguientes opciones relacionadas a la red: spring_layout(G), node_colorlinewidths, style ,font_size, font_family, node_size)
 

## Hallazgos Encontrados 📄 📌

La modalidad de Contratación que más se adjudica es la Contratación Directa, seguida de Régimen Especial y Mínima Cuantía.
 


!(C:\Users\Usuario\Documents\U ROSARIO\SEMESTRE I\METODOS COMPUTACIONALES POLITICA PUBLICA\proyecto final.jpg)


```python
#realizamos un plot de barras horizontal 
plt.title("Procesos Adjudicados por Modalidad de Contratación 2015 -Mayo 2020")
plt.xlabel("Número de procesos Adjudicados")
plt.ylabel("Modalidades de Contratación")
plt.savefig("Modalidades.jpg")
modalidad_contratos_count.plot(kind = 'barh', width=0.8, color = ['slategrey','lightsteelblue','navy']);
```


![png](output_9_0.png)



```python
# realizamos el mismo analisis pero ahora por tipo de contrato 
bienes_by_contratos = contratos.groupby('Tipo de Contrato')
```


```python
#agrupamos por tipo de contrato adjudicado 
bienes_contratos_count = bienes_by_contratos['ID Adjudicacion'].agg("count")
bienes_contratos_count
```




    Tipo de Contrato
    27 - Otros servicios               23537
    Acuerdo Marco                        606
    Alquiler de edificios               3886
    Arrendamiento Muebles                370
    Comisión                              67
    Compraventa                        28257
    Concesión                             68
    Consultoría                         3015
    Interventoría                       3293
    ND                                 28824
    No Especificado                        3
    Obra                                8301
    Seguros                             1429
    Servicios de aprovisionamiento    358726
    Suministros                        29653
    Ventas de muebles                     68
    Name: ID Adjudicacion, dtype: int64




```python
#organizamos de mayor a menor
bienes_contratos_count.to_frame().sort_values(by='ID Adjudicacion', ascending=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID Adjudicacion</th>
    </tr>
    <tr>
      <th>Tipo de Contrato</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Servicios de aprovisionamiento</th>
      <td>358726</td>
    </tr>
    <tr>
      <th>Suministros</th>
      <td>29653</td>
    </tr>
    <tr>
      <th>ND</th>
      <td>28824</td>
    </tr>
    <tr>
      <th>Compraventa</th>
      <td>28257</td>
    </tr>
    <tr>
      <th>27 - Otros servicios</th>
      <td>23537</td>
    </tr>
    <tr>
      <th>Obra</th>
      <td>8301</td>
    </tr>
    <tr>
      <th>Alquiler de edificios</th>
      <td>3886</td>
    </tr>
    <tr>
      <th>Interventoría</th>
      <td>3293</td>
    </tr>
    <tr>
      <th>Consultoría</th>
      <td>3015</td>
    </tr>
    <tr>
      <th>Seguros</th>
      <td>1429</td>
    </tr>
    <tr>
      <th>Acuerdo Marco</th>
      <td>606</td>
    </tr>
    <tr>
      <th>Arrendamiento Muebles</th>
      <td>370</td>
    </tr>
    <tr>
      <th>Concesión</th>
      <td>68</td>
    </tr>
    <tr>
      <th>Ventas de muebles</th>
      <td>68</td>
    </tr>
    <tr>
      <th>Comisión</th>
      <td>67</td>
    </tr>
    <tr>
      <th>No Especificado</th>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
#realizamos una gráfica tipo pie, añadiendole porcentajes y tomando un poco por fuera de la torta el tipo de contrato que más se adjudica
explode = (0,0,0,0,0,0,0,0,0,0,0,0,0,0.1,0,0)
labels = ["Otros servicios",
          "Acuerdo Marco",
          "Alquiler de edificios",
          "Arrendamiento Muebles",
          "Comisión",
          "Compraventa",
          "Concesión",
          "Consultoría",
          "Interventoría",
          "ND",
          "No Especificado",
          "Obra",
          "Seguros",
          "Servicios de aprovisionamiento",
          "Suministros",
          "Ventas de muebles"]

bienes_contratos_count.plot(kind = 'pie', autopct="%0.1f %%",cmap='Paired',figsize= (8,8),labels = None ,fontsize=6,explode=explode, startangle=180, pctdistance = 1.2)
plt.ylabel(' ')
plt.legend(labels, bbox_to_anchor=(1.5,1),loc="upper right")
plt.title('Número de procesos Adjudicados por Tipo de Contrato')
plt.axis("equal")
plt.show()
plt.savefig("TipoContrato.jpg")
```


![png](output_13_0.png)



    <Figure size 1368x648 with 0 Axes>



```python
#realizamos el pie sin porcentaje
explode = (0,0,0,0,0,0,0,0,0,0,0,0,0,0.1,0,0)
labels = ["Otros servicios",
          "Acuerdo Marco",
          "Alquiler de edificios",
          "Arrendamiento Muebles",
          "Comisión",
          "Compraventa",
          "Concesión",
          "Consultoría",
          "Interventoría",
          "ND",
          "No Especificado",
          "Obra",
          "Seguros",
          "Servicios de aprovisionamiento",
          "Suministros",
          "Ventas de muebles"]

bienes_contratos_count.plot(kind = 'pie',cmap='Paired',figsize= (8,8),labels = None ,fontsize=8,explode=explode, startangle=180, pctdistance = 1.1)
plt.ylabel(' ')
plt.legend(labels, bbox_to_anchor=(1.5,1),loc="upper right")
plt.title('Número de procesos Adjudicados por Tipo de Contrato')
plt.axis("equal")
plt.show()
```


![png](output_14_0.png)



```python
#realizamos el analisis por Departamento 
contratos_by_departamento = contratos.groupby('Departamento Entidad')
```


```python
#existe una gran cantidad de numero de procesos que no estan definidos por departamento 
#lo que haremos es eliminarlo usando indexación 
departamento_contratos_count = contratos_by_departamento['ID Adjudicacion'].agg("count")
departamento_contratos_count
```




    Departamento Entidad
    Amazonas                                      2129
    Antioquia                                    22809
    Arauca                                        9257
    Atlántico                                     5825
    Bolívar                                       3506
    Boyacá                                        8685
    Caldas                                        5277
    Caquetá                                       4912
    Casanare                                      2904
    Cauca                                         3600
    Cesar                                         1818
    Chocó                                         2361
    Cundinamarca                                  9153
    Córdoba                                       1290
    Distrito Capital de Bogotá                  157380
    Guainía                                        158
    Guaviare                                       395
    Huila                                         9938
    La Guajira                                     945
    Magdalena                                     3980
    Meta                                          4273
    Nariño                                        2813
    No Definido                                 174025
    Norte de Santander                            2123
    Putumayo                                      1689
    Quindío                                       2464
    Risaralda                                     2770
    San Andrés, Providencia y Santa Catalina       923
    Santander                                    15635
    Sucre                                         1708
    Tolima                                        5869
    Valle del Cauca                              18108
    Vaupés                                         155
    Vichada                                       1226
    Name: ID Adjudicacion, dtype: int64




```python
#una posible forma eliminar el elemento es con la función drop 
departamento_contratos_count.drop(['No Definido'])
```




    Departamento Entidad
    Amazonas                                      2129
    Antioquia                                    22809
    Arauca                                        9257
    Atlántico                                     5825
    Bolívar                                       3506
    Boyacá                                        8685
    Caldas                                        5277
    Caquetá                                       4912
    Casanare                                      2904
    Cauca                                         3600
    Cesar                                         1818
    Chocó                                         2361
    Cundinamarca                                  9153
    Córdoba                                       1290
    Distrito Capital de Bogotá                  157380
    Guainía                                        158
    Guaviare                                       395
    Huila                                         9938
    La Guajira                                     945
    Magdalena                                     3980
    Meta                                          4273
    Nariño                                        2813
    Norte de Santander                            2123
    Putumayo                                      1689
    Quindío                                       2464
    Risaralda                                     2770
    San Andrés, Providencia y Santa Catalina       923
    Santander                                    15635
    Sucre                                         1708
    Tolima                                        5869
    Valle del Cauca                              18108
    Vaupés                                         155
    Vichada                                       1226
    Name: ID Adjudicacion, dtype: int64




```python
#usando indexación, llamamos el elemento con el indice 22 que corresponde al que queremos eliminar, para ello cree la variable departamento 
departamento = departamento_contratos_count.to_frame().drop(departamento_contratos_count.index[22])
```


```python
#organizamos de mayor a menor
departamento.sort_values(by='ID Adjudicacion', ascending=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID Adjudicacion</th>
    </tr>
    <tr>
      <th>Departamento Entidad</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Distrito Capital de Bogotá</th>
      <td>157380</td>
    </tr>
    <tr>
      <th>Antioquia</th>
      <td>22809</td>
    </tr>
    <tr>
      <th>Valle del Cauca</th>
      <td>18108</td>
    </tr>
    <tr>
      <th>Santander</th>
      <td>15635</td>
    </tr>
    <tr>
      <th>Huila</th>
      <td>9938</td>
    </tr>
    <tr>
      <th>Arauca</th>
      <td>9257</td>
    </tr>
    <tr>
      <th>Cundinamarca</th>
      <td>9153</td>
    </tr>
    <tr>
      <th>Boyacá</th>
      <td>8685</td>
    </tr>
    <tr>
      <th>Tolima</th>
      <td>5869</td>
    </tr>
    <tr>
      <th>Atlántico</th>
      <td>5825</td>
    </tr>
    <tr>
      <th>Caldas</th>
      <td>5277</td>
    </tr>
    <tr>
      <th>Caquetá</th>
      <td>4912</td>
    </tr>
    <tr>
      <th>Meta</th>
      <td>4273</td>
    </tr>
    <tr>
      <th>Magdalena</th>
      <td>3980</td>
    </tr>
    <tr>
      <th>Cauca</th>
      <td>3600</td>
    </tr>
    <tr>
      <th>Bolívar</th>
      <td>3506</td>
    </tr>
    <tr>
      <th>Casanare</th>
      <td>2904</td>
    </tr>
    <tr>
      <th>Nariño</th>
      <td>2813</td>
    </tr>
    <tr>
      <th>Risaralda</th>
      <td>2770</td>
    </tr>
    <tr>
      <th>Quindío</th>
      <td>2464</td>
    </tr>
    <tr>
      <th>Chocó</th>
      <td>2361</td>
    </tr>
    <tr>
      <th>Amazonas</th>
      <td>2129</td>
    </tr>
    <tr>
      <th>Norte de Santander</th>
      <td>2123</td>
    </tr>
    <tr>
      <th>Cesar</th>
      <td>1818</td>
    </tr>
    <tr>
      <th>Sucre</th>
      <td>1708</td>
    </tr>
    <tr>
      <th>Putumayo</th>
      <td>1689</td>
    </tr>
    <tr>
      <th>Córdoba</th>
      <td>1290</td>
    </tr>
    <tr>
      <th>Vichada</th>
      <td>1226</td>
    </tr>
    <tr>
      <th>La Guajira</th>
      <td>945</td>
    </tr>
    <tr>
      <th>San Andrés, Providencia y Santa Catalina</th>
      <td>923</td>
    </tr>
    <tr>
      <th>Guaviare</th>
      <td>395</td>
    </tr>
    <tr>
      <th>Guainía</th>
      <td>158</td>
    </tr>
    <tr>
      <th>Vaupés</th>
      <td>155</td>
    </tr>
  </tbody>
</table>
</div>




```python
#realizamos la gráfica por departamento 
departamento.plot(kind="barh", color=['red'], figsize= (19.0,10.0))
plt.title("Numero de Procesos Adjudicados por Departamento")
plt.ylabel("Departamento");
plt.savefig("Departamento.jpg")
```


![png](output_20_0.png)



```python
#vamos analizar el DataFrame por tipo de fecha, para ello utilizamos parse_dates
contratos = pd.read_csv('SECOP_II_-_Procesos_de_Contratacion-2015-2020.csv', parse_dates=["Fecha de Publicacion del Proceso"])
```

    C:\Users\Usuario\anaconda3\lib\site-packages\IPython\core\interactiveshell.py:3063: DtypeWarning: Columns (17) have mixed types.Specify dtype option on import or set low_memory=False.
      interactivity=interactivity, compiler=compiler, result=result)
    


```python
#Invocamos la siguiente funcion con el fin de indicarle al programa que trabajaremos con series de tiempo y temporales 

def to_day(timestamp):
    return timestamp.replace(minute=0,hour=0, second=0)

contratos["Day"] = contratos["Fecha de Publicacion del Proceso"].apply(to_day)
```


```python
# realizamos una agrupación multiple por modalidad de contrato y fecha de públicacion 
contratos_by_day = contratos.groupby(['Fecha de Publicacion del Proceso','Modalidad de Contratacion']) 
contratos_by_day_count = contratos_by_day['Modalidad de Contratacion'].agg('count') 
contratos_by_day_count
```




    Fecha de Publicacion del Proceso  Modalidad de Contratacion                  
    2015-04-16                        Contratación régimen especial                  1
    2015-04-20                        Contratación régimen especial                  9
    2015-04-21                        Contratación régimen especial                  2
    2015-04-22                        Contratación régimen especial                  8
    2015-04-23                        Contratación régimen especial                  4
                                                                                    ..
    2020-05-20                        Contratación régimen especial (con ofertas)    1
                                      Licitación pública                             1
                                      Mínima cuantía                                 4
                                      Selección Abreviada de Menor Cuantía           2
                                      Solicitud de información a los Proveedores     2
    Name: Modalidad de Contratacion, Length: 10718, dtype: int64




```python
contratos_by_day_count.to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Modalidad de Contratacion</th>
    </tr>
    <tr>
      <th>Fecha de Publicacion del Proceso</th>
      <th>Modalidad de Contratacion</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-04-16</th>
      <th>Contratación régimen especial</th>
      <td>1</td>
    </tr>
    <tr>
      <th>2015-04-20</th>
      <th>Contratación régimen especial</th>
      <td>9</td>
    </tr>
    <tr>
      <th>2015-04-21</th>
      <th>Contratación régimen especial</th>
      <td>2</td>
    </tr>
    <tr>
      <th>2015-04-22</th>
      <th>Contratación régimen especial</th>
      <td>8</td>
    </tr>
    <tr>
      <th>2015-04-23</th>
      <th>Contratación régimen especial</th>
      <td>4</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">2020-05-20</th>
      <th>Contratación régimen especial (con ofertas)</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Licitación pública</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Mínima cuantía</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Selección Abreviada de Menor Cuantía</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Solicitud de información a los Proveedores</th>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>10718 rows × 1 columns</p>
</div>




```python
#organizamos de manera matricial con unstack 
contratos_by_day_serie = contratos_by_day_count.unstack('Modalidad de Contratacion') 
contratos_by_day_serie
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Modalidad de Contratacion</th>
      <th>Concurso de méritos abierto</th>
      <th>Contratación Directa (con ofertas)</th>
      <th>Contratación directa</th>
      <th>Contratación régimen especial</th>
      <th>Contratación régimen especial (con ofertas)</th>
      <th>Enajenación de bienes con sobre cerrado</th>
      <th>Enajenación de bienes con subasta</th>
      <th>Licitación Pública Acuerdo Marco de Precios</th>
      <th>Licitación pública</th>
      <th>Licitación pública Obra Publica</th>
      <th>Mínima cuantía</th>
      <th>Seleccion Abreviada Menor Cuantia Sin Manifestacion Interes</th>
      <th>Selección Abreviada de Menor Cuantía</th>
      <th>Selección abreviada subasta inversa</th>
      <th>Solicitud de información a los Proveedores</th>
    </tr>
    <tr>
      <th>Fecha de Publicacion del Proceso</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-04-16</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2015-04-20</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2015-04-21</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2015-04-22</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2015-04-23</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2020-05-16</th>
      <td>3.0</td>
      <td>5.0</td>
      <td>256.0</td>
      <td>43.0</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>NaN</td>
      <td>10.0</td>
      <td>4.0</td>
      <td>9.0</td>
    </tr>
    <tr>
      <th>2020-05-17</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>122.0</td>
      <td>32.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>2020-05-18</th>
      <td>1.0</td>
      <td>20.0</td>
      <td>639.0</td>
      <td>151.0</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>125.0</td>
      <td>NaN</td>
      <td>14.0</td>
      <td>10.0</td>
      <td>67.0</td>
    </tr>
    <tr>
      <th>2020-05-19</th>
      <td>3.0</td>
      <td>22.0</td>
      <td>784.0</td>
      <td>147.0</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.0</td>
      <td>4.0</td>
      <td>122.0</td>
      <td>1.0</td>
      <td>16.0</td>
      <td>21.0</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>2020-05-20</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>33.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>4.0</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>2.0</td>
    </tr>
  </tbody>
</table>
<p>1575 rows × 15 columns</p>
</div>




```python
#realizamos la gráfica por madalidades de contratación más concurridas por año
contratos_by_day_serie[['Contratación directa','Contratación régimen especial','Mínima cuantía', 'Contratación Directa (con ofertas)']].plot(figsize= (17.0,9.0))
plt.title("Malidades de Contratación más frecuentes por Año")
plt.xlabel(' ')
plt.xlabel("Año");
plt.savefig("Contratosporaño.jpg")
```


![png](output_26_0.png)



```python
#realizamos otra gráfica por otras modalidades de contratación importantes 
contratos_by_day_serie[['Mínima cuantía','Selección Abreviada de Menor Cuantía','Selección abreviada subasta inversa','Licitación pública']].plot();
plt.title("Otras Modalidades Importantes")
plt.xlabel(' ')
plt.xlabel("Año");
plt.savefig("otrasporaño.jpg")
```


![png](output_27_0.png)



```python
#realizamos en análisis por Modalidad de Contratación y Orden de la Entidad Compradora o Estatal.
contratos_by_orden_entidad = contratos.groupby(['Modalidad de Contratacion','OrdenEntidad',]) 
contratos_by_orden_entidad = contratos_by_orden_entidad ['Modalidad de Contratacion'].agg('count') 
contratos_by_orden_entidad
```




    Modalidad de Contratacion                                    OrdenEntidad        
    Concurso de méritos abierto                                  Corporación Autónoma        94
                                                                 Nacional                  2806
                                                                 Territorial               2508
    Contratación Directa (con ofertas)                           Corporación Autónoma        31
                                                                 Nacional                 16228
                                                                 Territorial               7618
    Contratación directa                                         Corporación Autónoma      1660
                                                                 Nacional                151745
                                                                 Territorial             124526
    Contratación régimen especial                                Corporación Autónoma      3252
                                                                 Nacional                 22645
                                                                 Territorial              38688
    Contratación régimen especial (con ofertas)                  Corporación Autónoma        21
                                                                 Nacional                  1193
                                                                 Territorial               3881
    Enajenación de bienes con sobre cerrado                      Nacional                    26
                                                                 Territorial                  5
    Enajenación de bienes con subasta                            Corporación Autónoma        15
                                                                 Nacional                    28
                                                                 Territorial                  5
    Licitación Pública Acuerdo Marco de Precios                  Nacional                   596
    Licitación pública                                           Corporación Autónoma        77
                                                                 Nacional                  2701
                                                                 Territorial               1926
    Licitación pública Obra Publica                              Corporación Autónoma         8
                                                                 Nacional                   959
                                                                 Territorial                990
    Mínima cuantía                                               Corporación Autónoma       234
                                                                 Nacional                 45220
                                                                 Territorial              11545
    Seleccion Abreviada Menor Cuantia Sin Manifestacion Interes  Corporación Autónoma         6
                                                                 Nacional                   147
                                                                 Territorial                152
    Selección Abreviada de Menor Cuantía                         Corporación Autónoma       182
                                                                 Nacional                 13457
                                                                 Territorial               4548
    Selección abreviada subasta inversa                          Corporación Autónoma       102
                                                                 Nacional                  9400
                                                                 Territorial               4038
    Solicitud de información a los Proveedores                   Corporación Autónoma         5
                                                                 Nacional                 11154
                                                                 Territorial               5681
    Name: Modalidad de Contratacion, dtype: int64




```python
#realizamos el DataFrame, en el cual se evidencia la cantidad de procesos por Modalidad y orden de la Entidad Estatal
contratos_by_orden_entidad.to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Modalidad de Contratacion</th>
    </tr>
    <tr>
      <th>Modalidad de Contratacion</th>
      <th>OrdenEntidad</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="3" valign="top">Concurso de méritos abierto</th>
      <th>Corporación Autónoma</th>
      <td>94</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>2806</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>2508</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Contratación Directa (con ofertas)</th>
      <th>Corporación Autónoma</th>
      <td>31</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>16228</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>7618</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Contratación directa</th>
      <th>Corporación Autónoma</th>
      <td>1660</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>151745</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>124526</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Contratación régimen especial</th>
      <th>Corporación Autónoma</th>
      <td>3252</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>22645</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>38688</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Contratación régimen especial (con ofertas)</th>
      <th>Corporación Autónoma</th>
      <td>21</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>1193</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>3881</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">Enajenación de bienes con sobre cerrado</th>
      <th>Nacional</th>
      <td>26</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>5</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Enajenación de bienes con subasta</th>
      <th>Corporación Autónoma</th>
      <td>15</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>28</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>5</td>
    </tr>
    <tr>
      <th>Licitación Pública Acuerdo Marco de Precios</th>
      <th>Nacional</th>
      <td>596</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Licitación pública</th>
      <th>Corporación Autónoma</th>
      <td>77</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>2701</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>1926</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Licitación pública Obra Publica</th>
      <th>Corporación Autónoma</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>959</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>990</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Mínima cuantía</th>
      <th>Corporación Autónoma</th>
      <td>234</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>45220</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>11545</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Seleccion Abreviada Menor Cuantia Sin Manifestacion Interes</th>
      <th>Corporación Autónoma</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>147</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>152</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Selección Abreviada de Menor Cuantía</th>
      <th>Corporación Autónoma</th>
      <td>182</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>13457</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>4548</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Selección abreviada subasta inversa</th>
      <th>Corporación Autónoma</th>
      <td>102</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>9400</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>4038</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">Solicitud de información a los Proveedores</th>
      <th>Corporación Autónoma</th>
      <td>5</td>
    </tr>
    <tr>
      <th>Nacional</th>
      <td>11154</td>
    </tr>
    <tr>
      <th>Territorial</th>
      <td>5681</td>
    </tr>
  </tbody>
</table>
</div>




```python
#gráficamos las más importantes 
ax1= contratos_by_orden_entidad[['Mínima cuantía']].plot(kind ='barh', color=['g','r','b'])
plt.title("Modalidad Mínima Cuantía por Orden de la Entidad Estatal")
plt.ylabel(' ')
plt.savefig("minima_orden.jpg")
```


![png](output_30_0.png)



```python
ax2= contratos_by_orden_entidad[['Contratación directa']].plot(kind ='barh', color=['m','y','c'])
plt.title("Modalidad Contratación directa por Orden de la Entidad Estatal")
plt.ylabel(' ')
plt.savefig("directa_orden.jpg")
```


![png](output_31_0.png)



```python
ax3= contratos_by_orden_entidad[['Licitación pública']].plot(kind ='barh', color=['bisque','darkorange','burlywood'])
plt.title("Modalidad Licitación Pública por Orden de la Entidad Estatal")
plt.ylabel(' ')
plt.savefig("licitacion_orden.jpg")
```


![png](output_32_0.png)



```python
ax4= contratos_by_orden_entidad[['Selección abreviada subasta inversa']].plot(kind ='barh', color=['salmon','coral','sienna'])
plt.title("Modalidad Selección abreviada subasta inversa por Orden de la Entidad Estatal")
plt.ylabel(' ')
plt.savefig("subasta_orden.jpg")
```


![png](output_33_0.png)



```python
ax5 = contratos_by_orden_entidad[['Selección Abreviada de Menor Cuantía']].plot(kind ='barh', color=['slategrey','lightsteelblue','royalblue'])
plt.title("Modalidad Selección Abreviada de Menor Cuantía por Orden de la Entidad Estatal")
plt.ylabel(' ')
plt.savefig("abreviada_orden.jpg")
```


![png](output_34_0.png)



```python
ax6 = contratos_by_orden_entidad[['Contratación régimen especial']].plot(kind ='barh', color=['mediumaquamarine','cadetblue','turquoise'])
plt.title("Modalidad Contratación régimen especial por Orden de la Entidad Estatal")
plt.ylabel(' ')
plt.savefig("especial_orden.jpg")
```


![png](output_35_0.png)



```python
#realizamos el análisis por el Monto total adjudicado por Modalidad de Contratación 
#cambiamos el nombre de la columana 'Valor Total Adjudicacion' por 'Monto'
contratos.rename(columns={'Valor Total Adjudicacion':'Monto'}, inplace=True)
```


```python
#el formato original csv presenta los montos separados por coma, es necesario cambiarlos 
contratos['Monto'] = contratos['Monto'].str.replace(",","")
```


```python
#realizamos la siguiente conversion 
contratos['Monto'] = pd.to_numeric(contratos.Monto, errors='coerce')
```


```python
#una vez el ajuste, realizamos el análisis por Modalidad de contratación y Monto total por cada una.
contratos_by_monto_modalidad = contratos.groupby(['Modalidad de Contratacion'])
```


```python
#sumamos los montos adjudicados por modalidad (sum)
contratos_by_monto = contratos_by_monto_modalidad['Monto'].agg(sum)
contratos_by_monto
```




    Modalidad de Contratacion
    Concurso de méritos abierto                                        2920585046698
    Contratación Directa (con ofertas)                               146899615328689
    Contratación directa                                                           0
    Contratación régimen especial                                                  0
    Contratación régimen especial (con ofertas)                    22748679920630048
    Enajenación de bienes con sobre cerrado                                192507588
    Enajenación de bienes con subasta                                     4351183066
    Licitación Pública Acuerdo Marco de Precios                          49994368088
    Licitación pública                                                19512161048230
    Licitación pública Obra Publica                                   10440596652153
    Mínima cuantía                                                     1931810200893
    Seleccion Abreviada Menor Cuantia Sin Manifestacion Interes        1246686868942
    Selección Abreviada de Menor Cuantía                               5202693035764
    Selección abreviada subasta inversa                                4207361341621
    Solicitud de información a los Proveedores                                     0
    Name: Monto, dtype: int64




```python
#realizamos el Dataframe
contratos_by_monto.to_frame()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Monto</th>
    </tr>
    <tr>
      <th>Modalidad de Contratacion</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Concurso de méritos abierto</th>
      <td>2920585046698</td>
    </tr>
    <tr>
      <th>Contratación Directa (con ofertas)</th>
      <td>146899615328689</td>
    </tr>
    <tr>
      <th>Contratación directa</th>
      <td>0</td>
    </tr>
    <tr>
      <th>Contratación régimen especial</th>
      <td>0</td>
    </tr>
    <tr>
      <th>Contratación régimen especial (con ofertas)</th>
      <td>22748679920630048</td>
    </tr>
    <tr>
      <th>Enajenación de bienes con sobre cerrado</th>
      <td>192507588</td>
    </tr>
    <tr>
      <th>Enajenación de bienes con subasta</th>
      <td>4351183066</td>
    </tr>
    <tr>
      <th>Licitación Pública Acuerdo Marco de Precios</th>
      <td>49994368088</td>
    </tr>
    <tr>
      <th>Licitación pública</th>
      <td>19512161048230</td>
    </tr>
    <tr>
      <th>Licitación pública Obra Publica</th>
      <td>10440596652153</td>
    </tr>
    <tr>
      <th>Mínima cuantía</th>
      <td>1931810200893</td>
    </tr>
    <tr>
      <th>Seleccion Abreviada Menor Cuantia Sin Manifestacion Interes</th>
      <td>1246686868942</td>
    </tr>
    <tr>
      <th>Selección Abreviada de Menor Cuantía</th>
      <td>5202693035764</td>
    </tr>
    <tr>
      <th>Selección abreviada subasta inversa</th>
      <td>4207361341621</td>
    </tr>
    <tr>
      <th>Solicitud de información a los Proveedores</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#organizamos el DataFrame de Mayor a Menor 
contratos_by_monto.to_frame().sort_values(by='Monto', ascending=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Monto</th>
    </tr>
    <tr>
      <th>Modalidad de Contratacion</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Contratación régimen especial (con ofertas)</th>
      <td>22748679920630048</td>
    </tr>
    <tr>
      <th>Contratación Directa (con ofertas)</th>
      <td>146899615328689</td>
    </tr>
    <tr>
      <th>Licitación pública</th>
      <td>19512161048230</td>
    </tr>
    <tr>
      <th>Licitación pública Obra Publica</th>
      <td>10440596652153</td>
    </tr>
    <tr>
      <th>Selección Abreviada de Menor Cuantía</th>
      <td>5202693035764</td>
    </tr>
    <tr>
      <th>Selección abreviada subasta inversa</th>
      <td>4207361341621</td>
    </tr>
    <tr>
      <th>Concurso de méritos abierto</th>
      <td>2920585046698</td>
    </tr>
    <tr>
      <th>Mínima cuantía</th>
      <td>1931810200893</td>
    </tr>
    <tr>
      <th>Seleccion Abreviada Menor Cuantia Sin Manifestacion Interes</th>
      <td>1246686868942</td>
    </tr>
    <tr>
      <th>Licitación Pública Acuerdo Marco de Precios</th>
      <td>49994368088</td>
    </tr>
    <tr>
      <th>Enajenación de bienes con subasta</th>
      <td>4351183066</td>
    </tr>
    <tr>
      <th>Enajenación de bienes con sobre cerrado</th>
      <td>192507588</td>
    </tr>
    <tr>
      <th>Contratación directa</th>
      <td>0</td>
    </tr>
    <tr>
      <th>Contratación régimen especial</th>
      <td>0</td>
    </tr>
    <tr>
      <th>Solicitud de información a los Proveedores</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
contratos_by_monto[['Contratación Directa (con ofertas)','Licitación pública Obra Publica','Licitación pública']].plot(kind ='barh', color=['mediumaquamarine','cadetblue','turquoise'])
plt.title("Modalidades de Contratación más frecuentes por Monto Adjudicado")
plt.savefig("monto_modalidad.jpg")
```


![png](output_43_0.png)


## Análisis de Redes 


```python
#importamos la libreria networkx que nos servira para la estructuracion de las redes y matplotlib para graficarla. 
import networkx as nx
import matplotlib.pyplot as plt
```


```python
#invocamos nuestro archivo de texto 
n = open('rednacional.txt', "rb")
```


```python
#lee el gráfico en formato de lista de adyacencia
G = nx.read_adjlist(n)
```

## Red Nacional - Entidad - Proveedores 


```python
G=nx.dodecahedral_graph()
nx.draw(G,pos=nx.spring_layout(G), node_color='r', linewidths = 1.0, style='solid',font_size = 15, font_family = 'sans-serif', node_size = 400)
fig = plt.figure(figsize=(20.0,150))
plt.savefig("rednacional.jpg")
plt.draw()
```


![png](output_49_0.png)



    <Figure size 1440x10800 with 0 Axes>



```python
G.nodes
```




    NodeView((0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19))




```python
G.edges
```




    EdgeView([(0, 1), (0, 19), (0, 10), (1, 2), (1, 8), (2, 3), (2, 6), (3, 4), (3, 19), (4, 5), (4, 17), (5, 6), (5, 15), (6, 7), (7, 8), (7, 14), (8, 9), (9, 10), (9, 13), (10, 11), (11, 12), (11, 18), (12, 13), (12, 16), (13, 14), (14, 15), (15, 16), (16, 17), (17, 18), (18, 19)])



## Red Territorial - Entidad - Proveedores


```python
t = open('redterritorial.txt', "rb")
```


```python
G = nx.read_adjlist(t)
```


```python
G=nx.dodecahedral_graph()
nx.draw(G,pos=nx.spring_layout(G), node_color='y', linewidths = 1.0, style='solid',font_size = 10, font_family = 'sans-serif', node_size = 400);
fig = plt.figure(figsize=(20.0,150))
plt.draw()
```


![png](output_55_0.png)



    <Figure size 1440x10800 with 0 Axes>



```python
F.nodes
```




    NodeView((0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19))




```python
F.edges
```




    EdgeView([(0, 1), (0, 19), (0, 10), (1, 2), (1, 8), (2, 3), (2, 6), (3, 4), (3, 19), (4, 5), (4, 17), (5, 6), (5, 15), (6, 7), (7, 8), (7, 14), (8, 9), (9, 10), (9, 13), (10, 11), (11, 12), (11, 18), (12, 13), (12, 16), (13, 14), (14, 15), (15, 16), (16, 17), (17, 18), (18, 19)])



## Red Ejercito Nacional - Proveedores 


```python
e = open('redejercito.txt', "rb")
```


```python
G = nx.read_adjlist(e)
```


```python
G=nx.dodecahedral_graph()
nx.draw(G,pos=nx.spring_layout(G), node_color='g', linewidths = 1.0, style='solid',font_size = 10, font_family = 'sans-serif', default=True ,node_size = 400);
fig = plt.figure(figsize=(20.0,150))
plt.draw()
```


![png](output_61_0.png)



    <Figure size 1440x10800 with 0 Axes>



```python
E.edges
```




    EdgeView([(0, 1), (0, 19), (0, 10), (1, 2), (1, 8), (2, 3), (2, 6), (3, 4), (3, 19), (4, 5), (4, 17), (5, 6), (5, 15), (6, 7), (7, 8), (7, 14), (8, 9), (9, 10), (9, 13), (10, 11), (11, 12), (11, 18), (12, 13), (12, 16), (13, 14), (14, 15), (15, 16), (16, 17), (17, 18), (18, 19)])




```python
E.nodes
```




    NodeView((0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19))




```python

```
